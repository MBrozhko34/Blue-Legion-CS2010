/*
 * Copyright (c) 2010-2020 Nathan Rajlich
 *
 *  Permission is hereby granted, free of charge, to any person
 *  obtaining a copy of this software and associated documentation
 *  files (the "Software"), to deal in the Software without
 *  restriction, including without limitation the rights to use,
 *  copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the
 *  Software is furnished to do so, subject to the following
 *  conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 *  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 *  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 *  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 *  OTHER DEALINGS IN THE SOFTWARE.
 */

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import org.java_websocket.WebSocket;
import org.java_websocket.drafts.Draft;
import org.java_websocket.drafts.Draft_6455;
import org.java_websocket.exceptions.WebsocketNotConnectedException;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

import com.mysql.cj.jdbc.CallableStatement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Random;


/**
 * A simple WebSocketServer implementation. Keeps track of a "chatroom".
 */
public class GameServer extends WebSocketServer {

	private Connection dManager = null;
	private int sessionID = 0;
	private int playerTurn;
	private ArrayList<WebSocket> s;
	private int recordID;
	private int p1H;
	private int p2H;
	
  public GameServer(int port) throws Exception {
    super(new InetSocketAddress(port));
    InitializeDB();
  }

  public GameServer(InetSocketAddress address) throws Exception {
    super(address);
    InitializeDB();
  }

  public GameServer(int port, Draft_6455 draft) throws Exception {
    super(new InetSocketAddress(port), Collections.<Draft>singletonList(draft));
    InitializeDB();
  }

  @Override
  public void onOpen(WebSocket conn, ClientHandshake handshake) {
    conn.send("Welcome to the server!"); //This method sends a message to the new client
    broadcast("PLAYER_JOINED " + conn.getRemoteSocketAddress().getHostName() /*+ handshake.getResourceDescriptor()*/); //This method sends a message to all clients connected
    //System.out.println(conn.getRemoteSocketAddress().getAddress().getHostAddress() + " entered the room!");
    
    if(getConnections().size()==2) {
//    	ArrayList<WebSocket> s = new ArrayList<WebSocket>(getConnections());
    	s = new ArrayList<WebSocket>(getConnections());
    	
    	System.out.println("number of connections: " + s.size());
    	
    	Random rand = new Random(); //instance of random class
        playerTurn = rand.nextInt(2);
        
        s.get(0).send("SESSION_START");
        s.get(1).send("SESSION_START");
        
        s.get(0).send("YOU_ARE_PLAYER 1");
        s.get(1).send("YOU_ARE_PLAYER 2");
        
        s.get(playerTurn).send("YOUR_TURN");
        
        try {
    		PreparedStatement preparedStatement = dManager.prepareStatement("insert into  bL.sessions values (default,default,?,?,?,?,?,?,?)", PreparedStatement.RETURN_GENERATED_KEYS);
        
            preparedStatement.setString(1, s.get(0).getRemoteSocketAddress().getHostName());
            preparedStatement.setInt(2, 100);
            
            if(playerTurn == 0) {
            	preparedStatement.setString(3, "active");
            } else {
            	preparedStatement.setString(3, "passive");
            }
            preparedStatement.setString(4, s.get(1).getRemoteSocketAddress().getHostName());
            preparedStatement.setInt(5, 100);
            
            if(playerTurn == 0) {
            	preparedStatement.setString(6, "passive");
            } else {
            	preparedStatement.setString(6, "active");
            }
            
            preparedStatement.setString(7, "active");
            
            int affected = preparedStatement.executeUpdate();
            ResultSet keys = null;
           
            if (affected == 1) {
                keys = preparedStatement.getGeneratedKeys();
                keys.next();
                sessionID = keys.getInt(1);
            	System.out.println("SessionID: " + sessionID);

            } else {
                System.err.println("No rows affected");
            }
    	} catch (SQLException e) {
    		e.printStackTrace();
    	}

        
//    	for (WebSocket client : getConnections()) {
//    	      if (client == conn) {
//    	    	  System.out.println("the same");
//    	    	  client.send("SESSION_START");
//    	    	  if(randomInt == 0) {
//    	    		  client.send("YOUR_TURN");
//    	    	  }
//    	      }
//    	      else {
//    	    	  System.out.println("different");
//    	    	  client.send("SESSION_START");
//    	    	  if(randomInt == 1) {
//    	    		  client.send("YOUR_TURN");
//    	    	  }
//    	      }
//    	    }
    }
  }
  
  public boolean gameDone() {
	  if(p1H <= 0) {
		  s.get(1).send("GAME_WON");
		  s.get(0).send("GAME_LOST");
		  broadcast("GAME_OVER");
		  System.out.println("GAME_OVER");
		  
		  return true;
	  } else if(p2H <= 0) {
		  s.get(0).send("GAME_WON");
		  s.get(1).send("GAME_LOST");
		  broadcast("GAME_OVER");
		  System.out.println("GAME_OVER");
		  
		  return true;
	  } else {
		  return false;
	  }
  }
  
  private void InitializeDB() throws Exception {
	  
          // This will load the MySQL driver, each DB has its own driver
          Class.forName("com.mysql.jdbc.Driver");
          // Setup the connection with the DB
          dManager = DriverManager.getConnection("jdbc:mysql://192.168.56.101/bL?" + "user=mike&password=12345678");
  }
  
  @Override
  public void onClose(WebSocket conn, int code, String reason, boolean remote) {
    broadcast(conn + " has left the room!");
    System.out.println(conn + " has left the room!");
    try {
//		
		PreparedStatement preparedStatement = dManager.prepareStatement("UPDATE bL.sessions SET GAME_STATUS=? WHERE ID=" + sessionID);
         
         preparedStatement.setString(1, "passive");
         
         preparedStatement.executeUpdate();
         sessionID=0;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
  
  public String CalculateHealth(PreparedStatement ps){
	  ps.toString();
	  return null;
  }
  
  @Override
  public void onMessage(WebSocket conn, String message) {
	try {
		int id=0;
		String p1Name=null;
		String p2Name=null;
		String p1Status=null;
		String p2Status=null; 
		int p1Health=0;
		int p2Health=0;
		String gameStatus=null;
//		Statement statement = dManager.createStatement();
//		ResultSet resultSet = statement.executeQuery("insert into bL.messages values(default, " + message + ")");
		PreparedStatement preparedStatement = dManager.prepareStatement("UPDATE bL.sessions SET PLAYER_1_HEALTH=?, PLAYER_2_HEALTH=? WHERE ID=" + sessionID);
		//preparedStatement.setString(1, message);
		System.out.println("This is player turn: " + playerTurn);
		System.out.println("message received: " + message);
		int activeClient = 2;
		
		Random r = new Random();
		
		if(s.get(0)==conn) {
			activeClient=0;
		} else if(s.get(1)==conn) {
			activeClient=1;
		} else {
			System.out.println("Can't find client");
		}
		
		String query = "SELECT * FROM bL.sessions WHERE ID=" +sessionID;
		Statement st = dManager.createStatement();
	    ResultSet rs = st.executeQuery(query);
	    if(rs.next()) {
	    	  id=rs.getInt("ID");
	    	  p1Name=rs.getString("PLAYER_1_NAME");
	    	  p2Name=rs.getString("PLAYER_2_NAME");
	    	  
	    	  p1Status=rs.getString("PLAYER_1_STATUS");
	    	  p2Status=rs.getString("PLAYER_2_STATUS");
	    	  
	    	  p1Health=rs.getInt("PLAYER_1_HEALTH");
	    	  p2Health=rs.getInt("PLAYER_2_HEALTH");
	    	  
	    	  gameStatus=rs.getString("GAME_STATUS");
	    }
	    
	    	if(playerTurn == activeClient) {
	    		if(playerTurn == 0) {
	    			playerTurn = 1;
	    			if(message.equals("ATTACK")) {

	    				int hReduce = r.nextInt(70);
	    				int netHealth=p2Health-hReduce;

	    				p1H = p1Health;
	    				p2H = netHealth;
	    				
	    				s.get(0).send("OTHER_HEALTH " + p2H);
	    				s.get(1).send("NEW_HEALTH " + p2H);

	    				preparedStatement.setInt(1, p1H);
	    				preparedStatement.setInt(2, p2H);
	    			} else if(message.equals("BOOST")) {
	    				int hBoost = r.nextInt(50);
	    				int netHealth=p1Health+hBoost;

	    				p1H = netHealth;
	    				p2H = p2Health;
	    				
	    				s.get(0).send("NEW_HEALTH " + p1H);
	    				s.get(1).send("OTHER_HEALTH " + p1H);

	    				preparedStatement.setInt(1, p1H);
	    				preparedStatement.setInt(2, p2H);
	    			} else {
	    				System.out.println("error");
	    				preparedStatement.setString(1, "error");
	    				//s.get(0).send("HEALTH BOOST");
	    			}
	    			s.get(1).send("YOUR_TURN");
	    			s.get(0).send("OTHER_TURN");
	    		} else if(playerTurn==1) {
	    			playerTurn=0;
	    			if(message.equals("ATTACK")) {
	    				int hReduce = r.nextInt(70);
	    				int netHealth=p1Health-hReduce;

	    				p1H=netHealth;
	    				p2H=p2Health;

	    				s.get(0).send("NEW_HEALTH "+ p1H);
	    				s.get(1).send("OTHER_HEALTH "+ p1H);

	    				preparedStatement.setInt(1, p1H);
	    				preparedStatement.setInt(2, p2H);
	    			} else if(message.equals("BOOST")) {
	    				int hBoost = r.nextInt(50);
	    				int netHealth=p2Health+hBoost;

	    				p1H=p1Health;
	    				p2H=netHealth;

	    				s.get(1).send("NEW_HEALTH " + p2H);
	    				s.get(0).send("OTHER_HEALTH "+ p2H);

	    				preparedStatement.setInt(1, p1H);
	    				preparedStatement.setInt(2, p2H);
	    			} else {
	    				System.out.println("error");
	    				//preparedStatement.setString(1, "error");
	    				//s.get(0).send("HEALTH REDUCE");
	    			}
	    			s.get(0).send("YOUR_TURN");
	    			s.get(1).send("OTHER_TURN");
	    		} else {
	    			System.out.println("error, randInt = " + playerTurn);
	    		}
	            preparedStatement.executeUpdate();
	    	} else {	    		
	    		conn.send("OUT_OF_TURN");
	    		//preparedStatement.setInt(2,);
	    	}
	    	if(gameDone()) {
	    		System.out.println("finished");
	    		for(WebSocket client: getConnections()) {
	    			client.close();
	    		}
	    	}

    	System.out.println("variable message= " + message);
			
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	//broadcast(message);
    System.out.println(conn.getRemoteSocketAddress().getHostName() + ": " + message);
  }

  @Override
  public void onMessage(WebSocket conn, ByteBuffer message) {
    broadcast(message.array());
    System.out.println(conn + ": " + message);
  }


  public static void main(String[] args) throws Exception {
    int port = 8887; // 843 flash policy port
    try {
      port = Integer.parseInt(args[0]);
    } catch (Exception ex) {
    }
    GameServer s = new GameServer(port);
    s.start();
    System.out.println("ChatServer started on port: " + s.getPort());

    BufferedReader sysin = new BufferedReader(new InputStreamReader(System.in));
    while (true) {
      String in = sysin.readLine();
      s.broadcast(in);
      if (in.equals("exit")) {
        s.stop(1000);
        break;
      }
    }
  }
  
  
  @Override
  public void onError(WebSocket conn, Exception ex) {
    ex.printStackTrace();
    if (conn != null) {
      // some errors like port binding failed may not be assignable to a specific websocket
    }
  }

  @Override
  public void onStart() {
    System.out.println("Server started!");
    setConnectionLostTimeout(0);
    setConnectionLostTimeout(100);
  }

}
