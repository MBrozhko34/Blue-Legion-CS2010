package com.mygdx.game.desktop;

public class Backdrop {

}
