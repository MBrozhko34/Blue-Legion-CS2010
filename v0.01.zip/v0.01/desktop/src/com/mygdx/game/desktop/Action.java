package com.mygdx.game.desktop;

public class Action {

}
