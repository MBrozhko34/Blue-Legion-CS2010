package com.mygdx.game.desktop;

public interface UI {
abstract void render();
abstract void create();
abstract void dispose();
}
