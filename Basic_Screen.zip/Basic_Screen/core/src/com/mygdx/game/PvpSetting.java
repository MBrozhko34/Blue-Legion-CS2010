package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class PvpSetting implements Screen {

	GameObj game;
	SpriteBatch batch;
	Texture img;
	private Texture myTexture;
	private TextureRegion myTextureRegion;
	private TextureRegionDrawable myTexRegionDrawable;
	private ImageButton button, button2, button3;
	private Stage stage;

	public PvpSetting(GameObj game) {
		this.game = game;
	}

	@Override
	public void show() { // first to get called
		// batch = new SpriteBatch();
		// img = new Texture("badlogic.jpg");

		myTexture = new Texture(Gdx.files.internal("back_button.png"));
		myTextureRegion = new TextureRegion(myTexture);
		myTexRegionDrawable = new TextureRegionDrawable(myTextureRegion);
		button = new ImageButton(myTexRegionDrawable); // Set the button up
		button.setSize(200, 100);
		button.setPosition(0, Gdx.graphics.getHeight() - 90);
		button.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				System.out.println("back");
				((Game) Gdx.app.getApplicationListener()).setScreen(new MainMenuScreen(game)); // jumps the game screen
																								// 2
			}
		});

		stage = new Stage(new ScreenViewport()); // Set up a stage for the ui
		stage.addActor(button); // Add the button to the stage to perform rendering and take input.
		Gdx.input.setInputProcessor(stage); // Start taking input from the ui

	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(1, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		Gdx.graphics.setTitle("PVP setting");
		// batch.begin();
		// batch.draw(img, 0, 0);
		// batch.end();
		stage.act();

		stage.draw();

	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		batch.dispose();
		img.dispose();
		stage.dispose();

	}

}
